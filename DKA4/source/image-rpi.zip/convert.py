# convert an image passed in as a command line arg into code that can be included!

# goal: output a pair of files named image.c and image.h, defining images the user can use in a C program.
# output something like:

# static const struct {
#   unsigned int		width;
#   unsigned int		height;
#   unsigned char		image_pixels[30 * 30 * 4 + 1];
#
# } lol;

import sys
from PIL import Image, ImageFilter

# print(f"Name of the script      : {sys.argv[0]=}")
print(f"// Arguments of the script : {sys.argv[1:]=}")

if len(sys.argv) < 2:
    print("Missing filename!")
    print("Expected usage: convert.py <filename>")
    exit(1);
filename = sys.argv[1]


# convert to data
def colorToARGB32(color):
    red = color[0]
    green = color[1]
    blue = color[2]
    # pack into 32 bit int
    result = 0
    result |= 0xFF << (8 * 3)
    result |=  red << (8 * 2)
    result |= green << (8 * 1)
    result |= blue
    return result

# sanity check
assert(colorToARGB32((255,255,255)) == 0xFFFFFFFF)

# use for later
type_def = "#pragma once \nstruct Image { \nunsigned int width; \nunsigned int height; \nunsigned int* data;\n};"
output_images = []

def printAsArray(colorData):
    height = len(colorData)
    width = len(colorData[0])

    array_as_hex = ""
    for row in range(height):
        for col in range(width):
            array_as_hex += hex(colorData[row][col])
            array_as_hex += ", "


    print("#pragma once")
    type_str = "struct Image { \nunsigned int width; \nunsigned int height; \nunsigned int data[" + str(width * height) + "];\n};"
    print(type_str)
    data_str = "static struct Image myImage = {" + str(width) + "," + str(height) + ", {" + array_as_hex + "} };"
    print(data_str)

with Image.open(filename) as im:

    # Blur the input image using the filter ImageFilter.BLUR
    im_blurred = im.filter(filter=ImageFilter.BLUR)

    height = im.height
    width = im.width
    image = []
    for row in range(height):
        image_row = []
        for col in range(width):
            color = im.getpixel((col,row))
            image_row.append(colorToARGB32(color))
        image.append(image_row)

    # finally, print the data as a C array
    printAsArray(image)
# the colors are already 8 bit, just need to mask them together
