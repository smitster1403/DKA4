- image credit to https://petricakegames.itch.io/cosmic-lilac/
- script by dylan leclair (will be updated soon!)

- usage example: `python3 convert.py sample-tile.jpg > image.h`